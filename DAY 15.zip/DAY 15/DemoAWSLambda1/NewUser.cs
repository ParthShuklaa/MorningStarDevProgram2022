﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoAWSLambda1
{
    public class NewUser
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }

    }
}
