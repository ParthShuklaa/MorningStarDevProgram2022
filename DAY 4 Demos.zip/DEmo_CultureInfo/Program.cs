﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace DEmo_CultureInfo
{
    class Program
    {
        static void Main(string[] args)

        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            double val = 12156320.55;
            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("en-GB");
            Console.WriteLine($"{val:C}");

            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("es-ES");

            Console.WriteLine($"{val:C}");

            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("hi-IN");

            Console.WriteLine($"{val:C}");
        }
    }
}
