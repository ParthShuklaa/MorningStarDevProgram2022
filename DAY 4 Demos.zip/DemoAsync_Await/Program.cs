﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAsync_Await
{
    class Program
    {
        public static async Task<int> Method1()
        {
            int count = 0;
            await Task.Run(() =>
            {
                for (int i = 0; i < 100; i++)
                {
                    Console.WriteLine("Method1");
                    //Task.Delay(100).Wait();
                    count += 1;
                }
            });
            return count;
        }

        public static async Task Method2()
        {
            await Task.Run(() =>
            {
                for (int i = 0; i < 20; i++)
                {
                    Console.WriteLine("Method2");
                    Task.Delay(100).Wait();
                }
            });
        }

        public static void Method3(int count) 
        {
            Console.WriteLine("Total Count is :{0}",count);
        }

        public static async Task Callmethod()
        {
            Task<int> task = Method1();
            Method2();
            int count = await task;
            Method3(count);
        }
    

        static async Task Main(string[] args)
        {
            //Method1();
            //Method2();
            
            await Callmethod();
            Console.ReadKey();


        }
    }
}
