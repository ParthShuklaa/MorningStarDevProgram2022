﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoParallelFor
{
    class Program
    {
         static long DoSomeIndependentTask()
        {
            long total = 0;
                for (int i = 0; i < 100000000 ; i++)
            {
                total += i;
            }
            return total;
        }
        static void Main(string[] args)
        {
            

           ParallelForDEmo();
           NormalForLoop();

        }

        public static  void ParallelForDEmo()
        {
            DateTime StartTime = DateTime.Now;
            Console.WriteLine(@"Parallel For Loop Execution Startes at :{0}", StartTime);

            Parallel.For(0, 10, i =>
            {
                long total = DoSomeIndependentTask();
                Console.WriteLine("{0} -{1}", i, total);
            });

            DateTime Endtime = DateTime.Now;
            Console.WriteLine(@"Parallel for loop Execution ends at :{0}",Endtime);

            TimeSpan span = Endtime - StartTime;
            int ms = (int)span.TotalMilliseconds;
            Console.WriteLine(@"Time taken to execute the loop in miliseconds {0}",ms);

        }
        public static void NormalForLoop()
        {
            Console.WriteLine("let us compare speed of For() and Parallel.for() in this Demo");
            DateTime StartTime = DateTime.Now;// Sarting time 

            Console.WriteLine(@"For Loop Execution Start at :{0}", StartTime);
            for (int i = 0; i < 10; i++)
            {
                long total = DoSomeIndependentTask();
                Console.WriteLine("{0} - {1}", i, total);
            }
            DateTime EndTime = DateTime.Now; /// Ending Time 
            Console.WriteLine(@"For Loop execution Ends at: {0} ", EndTime);

            TimeSpan span = EndTime - StartTime; //Total Time 
            int ms = (int)span.TotalMilliseconds;
            Console.WriteLine(@"Time taken to Execute the for loop in miliseconds {0}", ms);
        }
    }
}
