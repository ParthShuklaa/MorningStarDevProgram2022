﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo_TPL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("TPL was introduced in  C#4.0");
            Console.WriteLine($"main Thread : {Thread.CurrentThread.ManagedThreadId}");
            //Task mytask = Task<long>.Run(() =>
            //{
            //    long threadSum = 0;
            //    for (int i = 1; i <= 20; i++)
            //    {
            //        threadSum += (long)(Math.Sqrt(i));
            //    }
            //    return threadSum;
            //});
            Task maintask = new Task(printCounter);
            maintask.Start();

            Console.WriteLine($"main Thread : {Thread.CurrentThread.ManagedThreadId}");
            Console.ReadKey();
        }
        static void printCounter()
        {
            Console.WriteLine($"Child Thread : {Thread.CurrentThread.ManagedThreadId}");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Count value: {i}");
            }

            Console.WriteLine($"Child Thread : {Thread.CurrentThread.ManagedThreadId}");
        }
    }
}
