﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SchoolAdmissionManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAdmissionController : ControllerBase
    {
        // GET: api/<StudentAdmissionController>
        [HttpGet]
        public IEnumerable<StudentAdmissionDetailsModel> Get()
        {
            //Creating instance of the Model Class  
            StudentAdmissionDetailsModel admissionObj1 = new StudentAdmissionDetailsModel();
            StudentAdmissionDetailsModel admissionObj2 = new StudentAdmissionDetailsModel();

            admissionObj1.StudentID = 1;
            admissionObj1.StudentName = "Tejas";
            admissionObj1.StudentClass = "10th - A ";
            admissionObj1.DateofJoining = DateTime.Now;

            admissionObj2.StudentID = 2;
            admissionObj2.StudentName = "Prateek";
            admissionObj2.StudentClass = "10th - B ";
            admissionObj2.DateofJoining = DateTime.Now;

            //Creating List of Objects 
            List<StudentAdmissionDetailsModel> listofobj = new List<StudentAdmissionDetailsModel>
            {
                admissionObj1,admissionObj2
            };

            return listofobj;
        }

        // GET api/<StudentAdmissionController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<StudentAdmissionController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<StudentAdmissionController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<StudentAdmissionController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
