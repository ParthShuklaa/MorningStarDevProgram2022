﻿INSERT INTO [dbo].[Orders] ([ID], [ProductID], [Cost], [Placed], [CustomerID], [Status]) VALUES (, NULL, NULL, NULL, NULL, NULL)
