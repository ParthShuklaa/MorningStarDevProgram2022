﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CRMMicroservices.Repository;
using Microsoft.EntityFrameworkCore;

namespace CRMMicroservices.Model
{
    public class OrderRepository : IOrderRepository
    {
        //Creating a Ref of ApplicationContext INterface
        private IApplicationDbContext _dbContext;
        public  async Task<string> Add(OrderModel order)
        {
            //Adding Record into DB
            _dbContext.Orders.Add(order);
            await _dbContext.SaveChanges();
            return order.ID;
        }

        public  async Task<string> Cancel(string id)
        {
            var orderupt = await _dbContext.Orders.Where(orderdet => orderdet.ID == id).FirstOrDefaultAsync();
            if (orderupt == null) 
            {
                return "Order does not exist";
            }
            else
            {
                orderupt.Status = "Cancelled";
                await _dbContext.SaveChanges();
                return "Order Cancelled Successfully....!";
            }
        }

        public  async Task<OrderModel> GetByID(string id)
        {
            var order = await _dbContext.Orders.Where(orderDetails => orderDetails.ID == id).FirstOrDefaultAsync();
            return order;
        }

        public  async Task<OrderModel> GetCustomerById(string CustomerID)
        {
            var customer = await _dbContext.Orders.Where(orderdet => orderdet.CustomerID == CustomerID).FirstOrDefaultAsync();
            return customer;
        }
    }
}
