﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CRMMicroservices.Repository;

namespace CRMMicroservices.Model
{
    public class ApplicationContext:DbContext,IApplicationDbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options )
            :base(options)
        {

        }

        public DbSet<OrderModel> Orders { get; set; }

        public new async Task<int> SaveChanges()
        {
            return await base.SaveChangesAsync();
        }
    }
}
