﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRMMicroservices.Model;
using CRMMicroservices.Repository;

namespace CRMMicroservices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderModelsController : ControllerBase
    {
        private readonly ApplicationContext _context;
        private IOrderRepository _orderRepository;

        //public OrderModelsController(IOrderRepository orderRepository)
        //{
        //    _orderRepository = orderRepository;
        //}

        public OrderModelsController(ApplicationContext context, IOrderRepository orderRepository)
        {
            _context = context;
            _orderRepository = orderRepository;

        }

        // GET: api/OrderModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderModel>>> GetOrders()
        {
            return await _context.Orders.ToListAsync();
        }

        // GET: api/OrderModels/5

        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult> Add([FromBody] OrderModel orderdetails)
        {
            string orderid = await _orderRepository.Add(orderdetails);
            return Ok(orderid);

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<OrderModel>> GetOrderModel(string id)
        {
            var orderModel = await _context.Orders.FindAsync(id);

            if (orderModel == null)
            {
                return NotFound();
            }

            return orderModel;
        }

        [HttpGet]
        [Route("GetById/{id}")]
        public async Task<ActionResult> GetByID(string id)
        {
            var orderdetails = await _orderRepository.GetByID(id);
            return Ok(orderdetails);
        }

        // PUT: api/OrderModels/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrderModel(string id, OrderModel orderModel)
        {
            if (id != orderModel.ID)
            {
                return BadRequest();
            }

            _context.Entry(orderModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrderModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/OrderModels
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<OrderModel>> PostOrderModel(OrderModel orderModel)
        {
            _context.Orders.Add(orderModel);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (OrderModelExists(orderModel.ID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetOrderModel", new { id = orderModel.ID }, orderModel);
        }

        // DELETE: api/OrderModels/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<OrderModel>> DeleteOrderModel(string id)
        {
            var orderModel = await _context.Orders.FindAsync(id);
            if (orderModel == null)
            {
                return NotFound();
            }

            _context.Orders.Remove(orderModel);
            await _context.SaveChangesAsync();

            return orderModel;
        }

        private bool OrderModelExists(string id)
        {
            return _context.Orders.Any(e => e.ID == id);
        }
    }
}
