﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CRMMicroservices.Model;
using Microsoft.EntityFrameworkCore;

namespace CRMMicroservices.Repository
{
   public  interface IApplicationDbContext
    {
        DbSet<OrderModel> Orders { get; set; }
        Task<int> SaveChanges();
    }
}
