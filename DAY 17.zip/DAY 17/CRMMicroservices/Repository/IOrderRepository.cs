﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CRMMicroservices.Model;

namespace CRMMicroservices.Repository
{
   public interface IOrderRepository
    {
        Task<string> Add(OrderModel order);
        Task<OrderModel> GetByID(string id);
        Task<string> Cancel(string id);
        Task<OrderModel> GetCustomerById(string CustomerID);
    }
}
