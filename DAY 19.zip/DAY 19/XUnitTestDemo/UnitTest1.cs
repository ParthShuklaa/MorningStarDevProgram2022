using Demo_Testing;
using System;
using Xunit;



namespace XUnitTestDemo
{
    public class UnitTest1
    {
        [Fact]
        public void Task_Add_TwoNumber()
        {
            //Arange
            var num1 = 2.5;
            var num2 = 3.5;
            var expectedValue = 6;
            //Act
            var sum = MathOperation.Add(num1, num2);
            //Assert
            Assert.Equal(expectedValue, sum, 1);
        }

        [Fact]
        public void Task_Subtract_TwoNumber()
        {
            //Arange
            var num1 = 2.9;
            var num2 = 3.1;
            var expectedValue = -0.2;
            //Act
            var sum = MathOperation.Subtract(num1, num2);
            //Assert
            Assert.Equal(expectedValue, sum, 1);
        }

        [Fact]
        public void Task_Multiply_TwoNumber()
        {
            //Arange
            var num1 = 2.9;
            var num2 = 3.1;
            var expectedValue = 8.99;
            //Act
            var sum = MathOperation.Multiply(num1, num2);
            //Assert
            Assert.Equal(expectedValue, sum, 1);
        }

        [Fact]
        public void Task_Divide_TwoNumber()
        {
            //Arange
            var num1 = 2.9;
            var num2 = 3.1;
            var expectedValue = 0.94;
            //Act
            var sum = MathOperation.Divide(num1, num2);
            //Assert
            Assert.Equal(expectedValue, sum, 1);
        }
    }
}
