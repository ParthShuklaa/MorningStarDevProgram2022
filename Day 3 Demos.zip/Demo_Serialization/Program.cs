﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Text.Json;
//using System.Text.Json.serialization;
using Newtonsoft.Json;

namespace Demo_Serialization
{
    class Program
    {
        static void Main(string[] args)
        {
            var weatherForecast = new WeatherForecast
            {
                Date = DateTime.Parse("2022-05-01"),
                TemperatureCelsius = 41,
                Summary = "Hot"
            };

            //string jsonString = JsonSerializer.Serialize(weatherForecast,option);
            string JsonString = JsonConvert.SerializeObject(weatherForecast);
            Console.WriteLine(JsonString);
            Console.WriteLine("DESerialization from Json String to Custom .NEt Object ");
            string json = @"{
                'Name' :'James Bond',
                'Description': 'Secret Agent'
                }";
            Agents Mi6 = JsonConvert.DeserializeObject<Agents>(json);
            Console.WriteLine(Mi6.Name + Mi6.Description);
        }
    }
}
