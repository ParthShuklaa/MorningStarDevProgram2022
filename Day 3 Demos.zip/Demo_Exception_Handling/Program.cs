﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Exception_Handling
{
    class Program 
    {
        static void validate(int age)
        {
            if (age < 18)
            {
                throw new InvalidAgeException("Sorry, Your Age must be greater than 18");
            }

        }
        static void Main(string[] args)

        {
            int[] arr = { 1, 2, 3, 4, 5 };
            try
            {
                int v = 1;
                Console.WriteLine(22/v);
                Console.WriteLine(arr[3]);
                //Checking User Define Exception
                validate(10);
            }
            catch (IndexOutOfRangeException e)
            {

                Console.WriteLine("You index is out of its Range: {0}", e.Message);
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e.Message);
            }

            //catch (Exception e)//This should be the last exception in the exception handling catch heirarchy
            //{
            //    Console.WriteLine(e.Message);
            //}

            catch(InvalidAgeException e)
            {
                Console.WriteLine(e);
            }
            finally 
            {
                Console.WriteLine("This block will execute irespective of the exception");
            }
        }
    }
}
