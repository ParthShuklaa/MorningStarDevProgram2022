﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Virtual_Keyword
{
    public class BClass
    {
        public virtual string Name { get; set; }
        public  void GetInfo()
        {
            Console.WriteLine("Geting info from base Class ");
        }
            }
    class Program : BClass
    {
        private string name;
        public override string Name {
            get
            { return name; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    name = value;
                }
                else
                {
                    name = "No Value";
                }
            }
        }
        public new void GetInfo()
        {
            Console.WriteLine("Welcome to Derived class Get Info method");
        }
        static void Main(string[] args)
        {
            Console.WriteLine( "Implementing Virtual keyword");
            Program Dobj = new Program();
            Dobj.GetInfo();

            BClass BObj = new BClass();
            BObj.GetInfo();

            Dobj.Name = string.Empty;
            Console.WriteLine(Dobj.Name);

            BClass Bobj1 = new Program();// Ref of base class is assigned to Child class using new 
            Bobj1.GetInfo();


            //Override is extending the method of base class  with a new defination but in case of new it will hide the method of 
            //base class 
        }
    }
}
