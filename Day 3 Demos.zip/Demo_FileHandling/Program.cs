﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Demo_FileHandling
{
    class Program
    {
        public void readData() 
        {
            //Step1: Creating a Stream reader object  and opening file 

            StreamReader sr = new StreamReader(@"C:\Users\DELL\source\MDP 30 May\Demo_FileHandling\MyData.txt");
            //Step2: Reading file line by line 
            string content = sr.ReadLine();
            while (content!=null)
            {
                Console.WriteLine(content);
                content = sr.ReadLine();
            }
            Console.ReadLine();
            //Step3: Closing File
            sr.Close();
        }
        public void WritingData()
        {
            StreamWriter sw = new StreamWriter(@"C:\Users\DELL\source\MDP 30 May\Demo_FileHandling\MyData.txt");
            Console.WriteLine("Enter the text that want to write into the file");
            string msg = Console.ReadLine();
            sw.WriteLine(msg);
            sw.Flush();//Clearing Buffer
            sw.Close();

        }
        static void Main(string[] args)
        {
            
            Program p = new Program();
            p.WritingData();
            p.readData();

        }
    }
}
