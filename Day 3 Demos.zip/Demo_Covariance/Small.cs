﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Covariance
{
   public  class Small
    {
        //prepration for Weekend party (5-10 ppl)/5 functions 
        //Dance : basiC Steps  + 
    }
    public class Big : Small
    {
        //preparation  for Birthday party( 20-40 ppl) 10+ 5 functions
        //Advance Form of Dancing 
    }
     public class Bigger : Big
    {
        //preparation for marrige party (500 ppl)
        //Break Dance/Popping/Locking/Solo stage Performance

    }
}
