﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Covariance
{
    public delegate Small covarDel(Big mc);//Creating a Delegate
    class Program
    { 
        public static Big Method1(Big Bg)
        {
            Console.WriteLine("Method 1");
            return new Big();
        }

        public static Small Method2(Big bg)
        {
            Console.WriteLine("Method 2");
            return new Small();
        }

        public static Small Method3(Small sml)
        {
            Console.WriteLine("Method 3");
            return new Small();
        }
        public static Big method4(Small Sml)
        {
            Console.WriteLine("Method4");
            return new Big();
        }

        static void Main(string[] args)
        {
            covarDel del = Method1;
            //Small sm1 = del(new Big());

            //del = Method2;
            //Small sm2 = del(new Big());

            //here Delgate is expecting a return type  of Small(Base Class) but we can still assign Method1 that returns Big(Derived Class)
            //and also method2 having same signature 
            //Covariance allows us to assign a method to the delegate that has a less dervied return type

            del += Method2;
            del += Method3;
            del += method4;
            Small sm = del(new Big());
            int ;
            in32;
            Short int;

            //here Method3 has apramater of small class(base) where delegate expects a parameter of big class(derived) Still We Can 
            //use method3 with the delegate

        }
    }
}
