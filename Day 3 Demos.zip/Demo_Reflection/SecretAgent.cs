﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Reflection
{
    class SecretAgent
    {
        public string AgentCodename { get; set; }
        public int CodeNo { get; set; }
        public SecretAgent()
        {
            AgentCodename = "Ethan Hunt";
            CodeNo = 111;
        }
        public SecretAgent( int No, string name)
        {
            AgentCodename = name;
            CodeNo = No;
        }
        public void DisplayData()
        {
            Console.WriteLine("Name is :{0}",AgentCodename);
            Console.WriteLine("Code is :{0}",CodeNo);
            }
    }
}
