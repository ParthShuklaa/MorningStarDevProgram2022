﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Demo_Reflection
{
    class Program
    {

        static void Main(string[] args)
        {
            //Type t = typeof(string);
            ////We Will use reflection here for knowing more about string type like follow
            //Console.WriteLine("Name :{0}",t.Name);
            //Console.WriteLine("Full name: {0}",t.FullName);
            //Console.WriteLine("NameSpace :{0}",t.Namespace);
            //Console.WriteLine("Base Type: {0}",t.BaseType);

            //Declare Instace of  class Assembly
            //Call the Executing Assembly method to load the method

            Assembly exceuting = Assembly.GetExecutingAssembly();

            Type[] types = exceuting.GetTypes();
            foreach (var item in types)
            {
                Console.WriteLine("Class : {0},",item.Name);
                //For Displaying Class

                MethodInfo[] methods = item.GetMethods();
                foreach (var items in methods)
                {
                    Console.WriteLine("--------> Methods:{0}",items.Name);
                    
                    ParameterInfo[] parameters = items.GetParameters();
                    foreach (var arg in parameters)
                    {
                        Console.WriteLine("--------------------->Parameters: {0} Type:{1}",arg.Name,arg.ParameterType);
                    }
                }
            }



        }
    }
}
