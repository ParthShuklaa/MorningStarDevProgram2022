﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Delegate
{
    //Step1: Declaring a Delegate 
    delegate int Calculator(int n);
    public delegate int MyDelegate(int x, int y);//Second delegate
    class Program
    {
        static int Number = 10;
        public static int Add(int n)
        {
            Number = Number + n;
            return Number;
        }

        public static int Mul(int n)
        {
            Number = Number * n;
            return Number;
        }
        public static int getNumber()
        {
            return Number;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Delgate in C#");

            //Calculator del1 = new Calculator(Add); //Instantiating Delgate
            //Calculator del2 = new Calculator(Mul);
            //Calculator del3 = new Calculator();
            //del1(25);//Calling method using a Delegate ref (Function pointer)
            //Console.WriteLine(" After Creating del1 Delegate output is  " + getNumber());
            //del2(3);
            //Console.WriteLine(" After Creating del2 Delegate output is  " + getNumber());
            ////Mullticasting Delegate
            //Program p1 = new Program();
            //del2 += Program.Add(10);

            //Calculator c;
            //Calculator str = Add;
            //Calculator str1 = Mul;

            //c = str;
            //c += str1; //Chaining of Delegate
            //c(2);
            //Console.WriteLine(c.Invoke(5));
            //Console.WriteLine("   ****** Func Delegte in action******* ");

            MyDelegate Add = DelegateClass.Add;
            int sum = Add(2, 3);
            Console.WriteLine(sum);

            //MyDelegate del = DelegateClass.getValue;//this will be an error

            //Func, Action and Predicate Delegate 

            Action action1 = DelegateClass.ActionMethod;
            action1();//Action Delegate with no Arguments

            Action<string> action2 = DelegateClass.ShowMessage;
            action2("Hola....");//Action Delegate with One input parameter

            Func<int,int> function1 = DelegateClass.getValue;
            int values = function1(10);
            Console.WriteLine(values);

            Func <int, int, int>func2 = DelegateClass.Add;
            int result = func2(10, 20);
            Console.WriteLine(result);

            Predicate<object> predicate = DelegateClass.IsNumeric;//it is used to verify certian criteria of  method and retunrs out as boolean(T/F)
            bool number = predicate("12345");
            bool number2 = predicate("ab12cd");
            Console.WriteLine("Is Entered value  a Number :{0}",number);

            Console.WriteLine("Is Number2 a valid Number :{0}", number2);


        }
    }
}
 