﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Delegate
{
    class DelegateClass
    {
        public static int Add(int x , int y)
        {
            return x + y;
        }
        public static int getValue(int x)
        {
            return (10 + x);
        }

        public static void ShowValue(int x)
        {
            Console.WriteLine("Value:" +x);
        }
        public static void ActionMethod()
        {
            Console.WriteLine("Action Method is Invoked using Action Delegate.....");
        }
        public static void ShowEmpData(int age , string name)
        {
            Console.WriteLine("Name is : "+name);
            Console.WriteLine("Age is :" +age);
        }
        public static void ShowMessage(String msg)
        {
            Console.WriteLine(msg);
        }
        public static bool IsNumeric(object Expression)
        {
            double retunrNum;
            bool isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retunrNum);
            return isNum;
           
        }

    }
}
