﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoPartialClass
{
    public partial class Class1
    {
        partial void Genre(string Genretype); // only declaration is done 
        public void Display()
        {
            Console.WriteLine("Authors name is : " + Author_name);
            Console.WriteLine("Total No of sales" + Total_Sale);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine( " Implementing Partial Class ");

            Class1 myObj1 = new Class1("Robin Shamrma",15000);//Defined in Sperate File
            myObj1.Display(); //Defined Above this class 

        }
    }
}
