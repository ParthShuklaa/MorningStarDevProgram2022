﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoPartialClass
{
     public partial class Class1
    {
        private string Author_name;
        private int Total_Sale;

        public Class1 ( string a , int sales)
        {
            this.Author_name = a;
            this.Total_Sale = sales;
        }
        partial void Genre(string Genretype) // Defination of the Method
        {
            Console.WriteLine("The writer is famous for {0} Genre",Genretype);
        }
    }
    

}
