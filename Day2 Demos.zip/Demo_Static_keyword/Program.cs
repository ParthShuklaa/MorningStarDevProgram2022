﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Static_keyword
{
    class Program// Driver Class
    {
        static Program()//Static Constructor
        {
            Console.WriteLine(" Calling Static Constructor ....");
        }

        public Program( int j)//Instance Constructor
        {
            Console.WriteLine("Instance Constructor is invoked... " +j);
        }

        public string ShowDetails ( string name, string Designation)//Instance Method
        {
            return "Name :" + name + " Designation:" + Designation;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Demonstrating Static as a Modifier for Classes, variables, methods and Constructors ..");
            Console.WriteLine("Contents from my Static Class is {0}",Student.Name);

            Console.WriteLine("My Mobile Model name is :{0}",Mobile.Model_name);
            Mobile.Display();

            Program Obj1 = new Program(1); //First Object  
            Console.WriteLine(Obj1.ShowDetails("Mr Ratan TATA","Chairman of TaTa Group"));

            Program obj2 = new Program(2);//Second Object 
            Console.WriteLine(obj2.ShowDetails("Gautam Adani", " Chairman of Adani group"));

        }
    }
     static class Student// Static Class
    {
        public static string Name = "Alfred Novel";
    }
}
