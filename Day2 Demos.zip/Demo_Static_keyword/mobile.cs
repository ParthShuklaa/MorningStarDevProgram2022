﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Static_keyword
{
    class Mobile
    {
        public static string Model_name = "Oneplus 9T";

        public static void Display()
        {
            Console.WriteLine("One Plus is emerging brand of the year for youth and its latest model is {0} ",Model_name);
        }
    }
}
