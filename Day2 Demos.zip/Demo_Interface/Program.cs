﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Interface
{
    class Program : IFirstINterface,ISecondINterface
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Demonstrating Interface");
            Program Obj1 = new Program();
            Obj1.FirstDisplay();
            Obj1.SecondDisplay();

            IFirstINterface iobj1 = Obj1;
            iobj1.FirstDisplay();
            //iobj1.SecondDisplay();//Error as the ref is from First INterface 
            
        }

        public void FirstDisplay()
        {
           
            Console.WriteLine("Inside First Display");
        }

        public void SecondDisplay()
        {
            
            Console.WriteLine("Inside Second Display ");
        }
    }
}
