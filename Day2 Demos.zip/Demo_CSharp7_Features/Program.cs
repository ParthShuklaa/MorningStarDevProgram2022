﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_CSharp7_Features
{
    class Program
    {
        static void Main(string[] args)
        {
            //int Age = null; Error
            Nullable<int> Age = null;
            Console.WriteLine(Age.GetValueOrDefault());

            int? obj1 = null;
            Console.WriteLine(obj1.GetValueOrDefault());
            int? Salary = 25000;
            Console.WriteLine(Salary.Value);
            Console.WriteLine(Salary.GetValueOrDefault());
            Salary = null;
           // Console.WriteLine(Salary.Value);
            int package = Salary ?? 25000;//if Salry is null then Assign 25000 to package(Null - coalescing Operator)
            Console.WriteLine("Your Package is{0}",package);
            Console.WriteLine("Displaying array of dynamic type using Var");
            var arr = new[] { 1, 2, 3 };
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
            
        }
    }
}
