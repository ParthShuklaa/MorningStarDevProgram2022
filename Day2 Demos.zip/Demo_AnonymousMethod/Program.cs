﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_AnonymousMethod
{
    class Program
    {
        public delegate void CanadianLabradoer(string pet);//Delegate declaration
        public delegate void AnonumousFun();
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Anonymous method ....");
            string fav = "Parrot";

            CanadianLabradoer FemaleDog = delegate (string mypet)
            {
                Console.WriteLine("My Furry family member name is :{0} ", mypet);
                Console.WriteLine("and I like {0}" ,fav);
            };
            FemaleDog("Ginger");

            AnonumousFun fun = delegate ()
            {
                Console.WriteLine("This is a call to anonumous function...");
            };
            fun();

        }
    }
}
