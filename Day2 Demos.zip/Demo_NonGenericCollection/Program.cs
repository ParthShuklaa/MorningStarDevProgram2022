﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Demo_NonGenericCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Non - Genric Collection ");
            ArrayList MyWatches = new ArrayList();//Creating an Array List 
            Console.WriteLine("Capacity At the time of creation "+MyWatches.Capacity);
            MyWatches.Add("Tommy HilFiger");
            MyWatches.Add(1920);
            Console.WriteLine("After adding two elements");
            Console.WriteLine(MyWatches.Capacity);

            MyWatches.Add(true);
            MyWatches.Add('R');
            MyWatches.Add(5000.9999);
            Console.WriteLine("After 5 elements");
            Console.WriteLine(MyWatches.Capacity);

            foreach (var item in MyWatches)//Displaying items of Array List collection
            {
                Console.WriteLine(item);
            }


            Console.WriteLine("Totoal no of elements present in the Queue are {0}",MyWatches.Count);

            //Step1: Declaration
            List<string> MyShoes = new List<string>();
            MyShoes.Add("Action");
            MyShoes.Add("Red tape");
            MyShoes.Add("lee Cooper");
            MyShoes.Add("Bata");
           // MyShoes.Add(0909);

            foreach (var item in MyShoes)
            {
                Console.WriteLine(item);
            }


        }
    }
}
