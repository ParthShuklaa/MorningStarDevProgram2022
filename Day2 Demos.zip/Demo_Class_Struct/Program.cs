﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Class_Struct
{
    class Program
    {
        static void Main(string[] args)
        {
            Author Obj1 = new Author();
            Obj1.Details("Dr APJ Abdul kalam", "English", 100);

            Car myCar;
            myCar.Brand = "Tesla";
            myCar.Color = "Grey";
            myCar.Model = " Roadster";
            Console.WriteLine("Name of the Brand:"+myCar.Brand 
                +"Model name: "+ myCar.Model+
                " Color is :"+myCar.Color );
        }
    }
    class Author
    {
        public string name;
        public string language;
        public int ArticleNo;
        
        public void Details(string name, string lang,  int ArticleNo )
        {
            this.name = name;
            this.language = lang;
            this.ArticleNo = ArticleNo;

            Console.WriteLine("The name of the Author is :" +name
                +"\n Language is "+language
                +"\n Article No is "+ ArticleNo);
        }
    }
    struct Car
    {
        public string Brand;
        public string Model;
        public string Color;


    }
}
