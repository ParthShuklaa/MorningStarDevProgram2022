﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Maths_OPerations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Maths Operations Demo");
            Console.WriteLine(Math.Max(20,45));
            Console.WriteLine(Math.PI);
            Console.WriteLine(Math.Sqrt(16));
            Console.WriteLine(Math.Abs(-99.97979));
            Console.WriteLine(Math.Round(99.9999));
        }
    }
}
