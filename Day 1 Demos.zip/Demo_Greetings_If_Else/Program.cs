﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Greetings_If_Else
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Displaying Greetings of the Day ...");
            int time = 24;
            
            if (time < 12)
            {
                Console.WriteLine("Good Morning Folks...");
            }
            else if (time<16)
            {
                Console.WriteLine("Good Day");
            }
            else
            {
                Console.WriteLine("Good Evening");
            }

            string message = (time < 16) ? "Good Day" : "Good evening";
            Console.WriteLine(message);
        }
    }
}
