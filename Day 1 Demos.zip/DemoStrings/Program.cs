﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Demo Strings");
            string myString = "The Quick brown fox, jumps over the lazy dog";
            Console.WriteLine(myString[10]);//Accessing 10th Char
            Console.WriteLine(myString.IndexOf("j"));
            Console.WriteLine("length os the string " + myString.Length);
            Console.WriteLine("My String In Upper Case" + myString.ToUpper());
            Console.WriteLine("My String in Lower Case" + myString.ToLower());
            //WAP to Display message in fowllowing
            //My Firstname is "FName" and Last is "LName" - String INterpolation
            string fname = " Nikola";
            string Sname = " Tesla";
            Console.WriteLine($"my first name is {fname} and last name is {Sname}");//was introduced in C#6 version 
            Console.WriteLine("this is how concatenation can be done "+string.Concat(fname,Sname));
        }
    }
}
