﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_HelloWorld
{
    class Class1
    { /*int : for Storing integer values
       * double : for Storing Floating point no
       * char :  Stores single Char
       * string : stores text ex Hello world
       * boolean : stores yes/No
       * */

        //int age = 18;
        //Console.WriteLine("Age is :"+age);
    }
}
