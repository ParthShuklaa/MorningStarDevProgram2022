﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Day 1 Session on .NET Application Development");//passing string
            // using System  : We Can use System namespace for our class
            // We have Name Space  to organize our code ( It act as a container  for classes and other namespace 
            /* Class -  it is container  for data and methods.
             * C# is Case sensitive  " MyClass" is different from "myclass"
             *  Exit point (MyFunction( Entry Point )
             */
            Console.WriteLine(100 + 150); // passing int
            int age = 18; // 4Bytes
            Console.WriteLine("Age is :" + age);
            const int MyNum = 500;
            //Char takes 2 Bytes
            //Float takes 4 Bytes
            //Double takes 8 Bytes 
            //Boolean takes 1 Bit
            string Firstname = "Raj";// 2 Bytes per Char
            string LastName = "Kumar";
            string FullName = Firstname + LastName;
            Console.WriteLine(FullName);

        }
    }
}
