﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_UserInput
{
    class Program
    {
        static void Main(string[] args)
        {
           //Step1: Display Message
           //Step2: Save Information
           //Step3: Display the value  
            Console.WriteLine("Enter your name..!!! ");
            string name = Console.ReadLine();
            Console.WriteLine(" Enter Your Age...?");
            int age =  Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Your Name is: " +name);
            Console.WriteLine("Your Age is : " +age);






        }
    }
}
