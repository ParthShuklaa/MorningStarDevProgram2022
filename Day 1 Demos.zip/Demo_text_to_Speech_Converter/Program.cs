﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis; 

namespace Demo_text_to_Speech_Converter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Text to Speech Converter Console App");
            //Step 1: Adding Speech Functionality  and creating object ref and taking input form the user 
             string msg = Console.ReadLine();
            SpeechSynthesizer spk = new SpeechSynthesizer();//Creating object the for the Class 
           //Step 2: Setting Output to Default Audio device
           spk.SetOutputToDefaultAudioDevice();
            //Step 3: Calling Speak()
            spk.Speak(msg);
        }
    }
}
