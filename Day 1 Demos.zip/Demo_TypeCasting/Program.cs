﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_TypeCasting
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Type Casting" );
            int myInt = 12;
            double myDouble = myInt;//Automatically casting is done 

            Console.WriteLine(myInt);
            Console.WriteLine(myDouble);

            Console.WriteLine("Explicit Casting ");
            double myDouble1 = 7.98;
            int myInt1 = (int)  myDouble1;//manual Casting  double to int 
            Console.WriteLine(Convert.ToString(myInt));


            Console.WriteLine(myInt1);

        }
    }
}
