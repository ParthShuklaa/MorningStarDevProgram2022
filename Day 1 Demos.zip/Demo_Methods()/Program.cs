﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Methods__

    class Program

    {
        static void Display()
        {
            Console.WriteLine("I am Executing a Method...!!");
        }
        static void Display( string msg)
        {
            Console.WriteLine("You are using Second display message" +msg);
        }
        static void Greeting( string name)
        {
            Console.WriteLine("hi Good Morning" + name);
        }
        static void Greeting( string msg, string name)
        {
            Console.WriteLine($"Your name is {name} Message is {msg} ");
        }
        static void Main(string[] args)
        {
            Display();
            Display("Second version of Display");
           

            Greeting("Micheal");
            Greeting("Hi there","Tony");

        }
    }
}
