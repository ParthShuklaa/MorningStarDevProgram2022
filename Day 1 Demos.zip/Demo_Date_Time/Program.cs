﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo_Date_Time
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Displaying Current Date and Time");
            //DateTime todayTime = new DateTime();
            //DateTime OnlyDate = new DateTime(2022, 05, 30);
            //DateTime onlyTime = new DateTime(100000000000);
            //Console.WriteLine("Time of the Day {0}",todayTime.TimeOfDay);
            //Console.WriteLine("Day{0}",OnlyDate.Day);
            //Console.WriteLine("Time of the Day{0}  ",onlyTime.TimeOfDay);

            DateTime myDateTime = new DateTime(2022, 7, 10, 5, 10, 25);
            Console.WriteLine("Day:{0}",myDateTime.Day);
            Console.WriteLine("Month{0}",myDateTime.Month);
            Console.WriteLine("Day of the Week{0}",myDateTime.DayOfWeek);
            Console.WriteLine("Day of the Year{0}",myDateTime.DayOfYear);

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(" DateTime is {0}",DateTime.Now);
                Thread.Sleep(2000);
                
            }

        }
    }
}
