﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoClasses_and_Object
{
    class Car//Step1: Creating a Class 
    {
        public string Color = "red";//Defining its memebers 
        public int maxSpeed = 250;
        private string CarModel = "BMW";//Private 
        public string MyProperty
        {
            get { return CarModel; } //get method   
            set { CarModel = value; } // Set method
        }
        public string EngineType { get; set; }
        public void HybridMode()
        {
            Console.WriteLine("This Car Supports Hubrid Mode");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Creating Object of the Class
            //
            Car obj1 = new Car();
            obj1.MyProperty = "Land Rover";//Setting value of property 
            Console.WriteLine(obj1.Color);
            obj1.HybridMode();
            Console.WriteLine(obj1.maxSpeed);
            Console.WriteLine(obj1.MyProperty); // getting vcalue of property
            obj1.EngineType = "Hybrid";
            Console.WriteLine(obj1.EngineType);
           


        }
    }
}
